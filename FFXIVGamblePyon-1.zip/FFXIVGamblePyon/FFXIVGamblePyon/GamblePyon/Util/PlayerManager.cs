﻿using FFXIVClientStructs.FFXIV.Client.Game.Group;
using GamblePyon.Config;
using GamblePyon.Models;
using System.Collections.Generic;

namespace GamblePyon.Util
{
    public unsafe class PlayerManager /* : IDisposable */
    {
        private const int GroupMemberOffset = 0x0CC8;
        private const int AllianceMemberOffset = 0x0E14;
        private const int AllianceSizeOffset = 0x0EB4;
        private const int GroupMemberSize = 0x20;
        private const int GroupMemberIdOffset = 0x18;

        public PlayerManager()
        {

        }

        public void UpdateParty(ref List<Player> players, string dealerName, NameMode nameMode)
        {

            List<Player> partyMembers = [];

            int groupMemberCount = GroupManager.Instance()->MainGroup.MemberCount;
            for (var i = 0; i < groupMemberCount; i++)
            {
                var memberStruct = GroupManager.Instance()->MainGroup.GetPartyMemberByIndex(i);
                var partyMember = GamblePyon.PartyList.CreatePartyMemberReference(new nint(memberStruct));

                if (partyMember == null)
                {
                    continue;
                }
                if (partyMember.Name.TextValue == dealerName)
                {
                    continue;
                }
                var newPlayer = new Player((int)partyMember.ObjectId, partyMember.Name.TextValue);
                newPlayer.Alias = newPlayer.GetAlias(nameMode);
                partyMembers.Add(newPlayer);
            }

            foreach (var player in players)
            {
                if (partyMembers.Find(x => x.ID == player.ID) == null)
                {
                    player.Name = "";
                }
            }

            players.RemoveAll(player => player.Name == "");

            foreach (var partyMember in partyMembers)
            {
                if (players.Find(x => x.ID == partyMember.ID) == null)
                {
                    players.Add(partyMember);
                }
            }
        }
    }
}
